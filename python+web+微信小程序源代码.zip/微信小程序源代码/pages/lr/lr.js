// pages/lr/lr.js
const { $Message } = require('../../dist/base/index');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    lr: 16,
    light_s: null,
    air_s: null,
    air_c: null,
    token: null
  },
  change({   detail  }) {//温度
    var that=this
    if(16<=detail.value&&detail.value<=30){
      this.setData({
        lr: detail.value
      })
      var token = this.data.token
      var num = detail.value
      wx.request({
        url: 'https://www.zhuizhu21.cn:8443/doControl',
        data: {
          token: token,
          target: 'lrair_temp',
          status: num
        }
      })
    }
    else {
      $Message({
        content: '温度设定范围为16~30°C',
        type: 'error'
      });
    }
    
    
  },

  light_s(event) {//灯
    const detail = event.detail;
    this.setData({
      light_s: detail.value
    })
    var status;
    var token=this.data.token
    var that=this
    if(detail.value){
      status="开启"
    }
    else{
      status="关闭"
    }
    wx.request({
      url: 'https://www.zhuizhu21.cn:8443/doControl',
      data:{
        token: token,
        target: 'lrlight',
        status: status
      },
    })
  },

  air_s(event) {
    const detail = event.detail;
    this.setData({
      air_s: detail.value
    })
    var status;
    var token = this.data.token
    var that = this
    if (detail.value) {
      status = "开启"
    }
    else {
      status = "关闭"
    }
    wx.request({
      url: 'https://www.zhuizhu21.cn:8443/doControl',
      data: {
        token: token,
        target: 'lrair_switch',
        status: status
      },
    })
  },

  air_c(event) {
    var that=this
    const detail = event.detail;
    this.setData({
      air_c: detail.value
    })
    var flag;
    if(!detail.value){
      flag="制热"
    }
    else{
      flag="制冷"
    }
    console.log(flag)
    wx.request({
      url: 'https://www.zhuizhu21.cn:8443/doControl',
      data: {
        token: that.data.token,
        target: 'lrair_flag',
        status: flag
      },
    })
  },
  refresh:function(){
    var that = this
    const token = wx.getStorageSync('token')
    wx.request({
      url: 'https://www.zhuizhu21.cn:8443/getData',
      data: {
        token: token
      },
      success(res) {
        const data = res.data.data
        console.log(data)
        wx.setStorageSync('data', data)
        that.setData({
          token: token,
          lr: data[5],
          light_s: data[4],
          air_s: data[7],
          air_c: data[6]
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    const token = wx.getStorageSync('token')
    wx.request({
      url: 'https://www.zhuizhu21.cn:8443/getData',
      data: {
        token: token
      },
      success(res) {
        const data = res.data.data
        // console.log(data)
        wx.setStorageSync('data', data)
        console.log(data[5],data[4],data[7],data[6])
        var light_s = data[4] == "关闭" ? false : true
        var air_s = data[7] == "关闭" ? false : true
        var air_c = data[6] == "制热" ? false : true
        var lr=data[5]
        that.setData({
          token: token,
          lr: lr,
          light_s: light_s,
          air_s: air_s,
          air_c:air_c
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})