// pages/kc/kc.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    smoke:null,
    switchs:null,
    token:null
  },
  change(event) {//灯
    const detail = event.detail;
    this.setData({
      switchs: detail.value
    })
    var status;
    var token = this.data.token
    var that = this
    if (detail.value) {
      status = "开启"
    }
    else {
      status = "关闭"
    }
    wx.request({
      url: 'https://www.zhuizhu21.cn:8443/doControl',
      data: {
        token: token,
        target: 'kcswitch',
        status: status
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    const token = wx.getStorageSync('token')
    console.log(token)
    wx.request({
      url: 'https://www.zhuizhu21.cn:8443/getData',
      data: {
        token: token
      },
      success(res) {
        const data = res.data.data
        // console.log(data)
        wx.setStorageSync('data', data)
        console.log(data[14])
        var status=data[14]=="关闭"?false:true
        that.setData({
          switchs:status,
          smoke:data[15],
          token:token
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})