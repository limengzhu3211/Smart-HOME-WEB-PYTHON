// pages/data/data.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id:null,
    temp:null,
    hum:null,
    win:null,
    door:null,
    show: true,
    animation_left: 'left_left',
    animation_right: 'right_right',
    animation_show_input: 'show_input',
    animation_avatar: 'avatar_top',
    animation_login: 'login',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var yhm=wx.getStorageSync('yhm')
    var passwd=wx.getStorageSync('passwd')
    wx.request({
      url: 'https://www.zhuizhu21.cn:8443/doLogin',
      data: {
        yhm: yhm,
        passwd: passwd,
        api: ''
      },
      success(res) {
        // console.log(res.data)
        wx.setStorageSync('token', res.data.token);
        var token=res.data.token
        wx.request({
          url: 'https://www.zhuizhu21.cn:8443/getData',
          data: {
            token: token
          },
          success(res) {
            const data = res.data.data
            console.log(data)
            that.setData({
              id: data[1],
              temp: data[16],
              hum: data[17],
              door: data[8],
              win: data[9]
            })
            wx.setStorageSync('data', data)
          }
        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})