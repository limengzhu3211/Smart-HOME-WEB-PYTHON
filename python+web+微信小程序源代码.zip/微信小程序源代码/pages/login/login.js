// pages/login/login.js
const app = getApp();
const util = require("../../utils/util.js");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    show: true,
    animation_left: 'left_left',
    animation_right: 'right_right',
    animation_show_input: 'show_input',
    animation_avatar: 'avatar_top',
    animation_login: 'login',
    no_info: false
  },
  //提交表单
  formSubmit: function (e) {
    var that = this
    console.log(e);
    if (e.detail.value.numinput.length <= 10) {
      if (that.data.show) {
        that.setData({
          animation_show_input: 'hidden_input',
          animation_left: 'left_right',
          animation_right: 'right_left',
          animation_avatar: 'avatar_down',
          animation_login: 'login_hidden',
          show: false
        })
      } else {
        that.setData({
          animation_show_input: 'show_input',
          animation_left: 'left_left',
          animation_right: 'right_right',
          animation_avatar: 'avatar_top',
          animation_login: 'login',
          show: true
        })
      }
      const yhm = e.detail.value.numinput;
      const passwd = e.detail.value.passinput;
      wx.showLoading({
        title: '登录中...',
        mask: true
      })
      wx.request({
        url: 'https://www.zhuizhu21.cn:8443/doLogin',
        // method:'post',
        data: {
          yhm: yhm,
          passwd: passwd,
          api: ''
        },
        success(res) {
          wx.hideLoading()
          console.log(res.data)
          if (res.data.status == 'success') {
            wx.setStorageSync('token', res.data.token)
            wx.setStorageSync('yhm', yhm);
            wx.setStorageSync('passwd', passwd)
            wx.redirectTo({
              url: '/pages/data/data',
            })
          }
          else {
            wx.hideLoading();
            wx.showToast({
              title: res.data.msg,
              icon: 'none',
              duration: 2000
            })
            if (that.data.show) {
              that.setData({
                animation_show_input: 'hidden_input',
                animation_left: 'left_right',
                animation_right: 'right_left',
                animation_avatar: 'avatar_down',
                animation_login: 'login_hidden',
                show: false
              })
            } else {
              that.setData({
                animation_show_input: 'show_input',
                animation_left: 'left_left',
                animation_right: 'right_right',
                animation_avatar: 'avatar_top',
                animation_login: 'login',
                show: true
              })
            }
          }
        }
      })
    }
    else {
      wx.showToast({
        title: '请按要求输入!',
        icon: 'none',
        duration: 3500
      })
    }


  },
  /**
 * 生命周期函数--监听页面加载
 */
  onLoad: function (options) {
    wx.getSetting({
      success: res => {
        if (!res.authSetting['scope.userInfo']) {
          this.setData({
            no_info: true
          })
        } else {
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.setData({
                userInfo: res.userInfo
              })
            }
          })
        }
      }
    })

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //判断授权是否同意
  getuserinfo: function (e) {
    if (e.detail.errMsg === "getUserInfo:fail auth deny") {
      wx.showToast({
        title: "请同意授权",
        icon: "none"
      })
    } else {
      wx.getUserInfo({
        success: res => {
          // 可以将 res 发送给后台解码出 unionId
          this.setData({
            userInfo: res.userInfo,
            no_info: false
          })
        }
      })

    }
  },
})