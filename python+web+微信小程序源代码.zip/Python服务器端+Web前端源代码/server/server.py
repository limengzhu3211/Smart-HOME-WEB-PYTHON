from flask import Flask,request,render_template,session,redirect
from util.SignUtil import DoSignin,IsSigned
from util.DataUtil import GetDetail,DoControl,GetData,LocalControl,GetDataL,GetDataPic
from util.draw import draw1,draw2
import json
import random
from pyecharts import EffectScatter,Timeline

app=Flask(__name__)
app.secret_key='some string to sign'

REMOTE_HOST = "https://pyecharts.github.io/assets/js"

#页面路由部分
@app.route('/')
def index():
    '''
    首页
    '''
    return render_template('index.html')

@app.route('/sign')
def sign():
    '''
    注册页面
    '''
    return render_template('sign.html')

@app.route('/logout')
def logout():
    '''
    退出登录 删除session
    '''
    session.__delitem__('yhm')
    session.__delitem__('token')
    return redirect('/')

@app.route('/admin')
def admin():
    '''
    管理页面
    '''

    if 'yhm' in session and 'token' in session:
        yhm=session.get('yhm')
        token=session.get('token')
        res=GetDetail(token)
        tem = draw1(token)
        hum=draw2(token)
        if res[0]:
            return render_template('admin.html',
                                   yhm=yhm,
                                   data=res[1],
                                   token=token,
                                   tem=tem.render_embed(),
                                   hum=hum.render_embed(),
                                   host=REMOTE_HOST,
                                   script_list=hum.get_js_dependencies(),
                                   )
        else:
            return redirect('/')
    else:
        print('dont')
        return redirect('/')


#后台API部分
@app.route('/doSignin',methods=['GET'])
def doSignin():
    '''
    处理注册表单 API与WEB
    '''
    if len(request.args)<3:
        return '参数错误!'
    yhm=request.args.get('yhm')
    passwd=request.args.get('passwd')
    device=request.args.get('device')
    flag=DoSignin(yhm, passwd, device)
    if 'api' in request.form:# API形式
        if flag[0]:
            return json.dumps({"status":"success","token":flag[1]})
        else:
            return json.dumps({"status":"fail","token":"null"})
    else:#网页形式
        if flag[0]:
            session['yhm'] = yhm
            session['token']=flag[1]
            return redirect('admin')
        else:
            return render_template('sign.html', info="注册失败，请更换用户名！")

@app.route('/doLogin',methods=['GET'])
def doLoginin():
    '''
    处理登录表单 API与WEB
    '''
    print(request.args)
    if len(request.args)<2:
        return '参数错误'
    yhm=request.args.get('yhm')
    passwd=request.args.get('passwd')
    flag=IsSigned(yhm,passwd)
    if 'api' in request.args:# API形式
        if flag[0]:
            return json.dumps({"status":"success","msg":"登陆成功","token":flag[1]},ensure_ascii=False)
        else:
            return json.dumps({"status":"fail","msg":"用户名与密码不匹配","token":"null"},ensure_ascii=False)
    else:#网页形式
        if flag[0]:
            session['token'] = flag[1]
            session['yhm']=yhm
            return redirect('admin')
        else:
            return render_template('index.html', info="用户名或密码错误！")

@app.route('/getData',methods=['GET'])
def getData():#获取最新记录
    '''
    根据传入的token获取数据
    '''
    if len(request.args)<1:
        return "参数错误"
    token=request.args['token']
    res=GetDetail(token)
    if res[0]:
        return json.dumps({"status":"success","data":res[1]},ensure_ascii=False)
    else:
        return json.dumps({"status":"fail","data":"null"})

@app.route('/getDatas',methods=['GET'])
def getDatas():#获取制定数目的记录
    if len(request.args)<2:
        return "参数错误"
    token=request.args['token']
    limit=request.args['limit']
    res=GetData(token,limit)
    return json.dumps(res,ensure_ascii=False)


@app.route('/data2pic',methods=['GET'])
def getDataPic():#获取制定数目的记录
    '''
    绘图数据接口
    '''
    if len(request.args)<2:
        return "参数错误"
    token=request.args['token']
    limit=request.args['limit']
    res=GetDataPic(token,limit)
    return json.dumps(res,ensure_ascii=False)


@app.route('/doControl',methods=['GET'])
def doControl():
    '''
    接收需要控制的对象 对对象的操作
    '''
    if len(request.args)<3:
        return '参数错误'
    target=request.args['target']
    status=request.args['status']
    token=request.args['token']
    DoControl(token,target,status)
    return json.dumps({"status":"success"})

@app.route('/doLocalControl',methods=['GET'])
def localControl():
    '''
    接受本地数据上传
    '''
    if len(request.args)<1:
        return "参数错误"
    device_id=request.args.get('device_id')
    LocalControl(device_id)
    return '200'

@app.route('/localData',methods=['GET'])
def localData():
    '''
    返回数据 控制中控
    '''
    if len(request.args)<1:
        return '参数错误'
    device_id=request.args.get('device_id')
    data=GetDataL(device_id)
    return json.dumps({"data":data},ensure_ascii=False)


#test
@app.route("/chart")
def hello():
    s3d = demo()
    return render_template(
        "admin.html",
        myechart=s3d.render_embed(),
        host=REMOTE_HOST,
        script_list=s3d.get_js_dependencies(),
    )





if __name__=='__main__':
    app.run(debug=True)