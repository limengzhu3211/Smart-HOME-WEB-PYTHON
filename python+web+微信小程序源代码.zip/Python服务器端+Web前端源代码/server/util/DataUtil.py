import sqlite3
import datetime
import random
BASE_PATH="/media/sh/软件/code/pycode/HomeAPI/server/DataBase/"
# BASE_PATH="/opt/flask/test/HomeAPI/server/DataBase/"
class DB():
    '''
    封装数据库类
    '''
    def __init__(self):
        self.conn=sqlite3.connect(BASE_PATH+'database')
        self.cur=self.conn.cursor()

    def getcur(self):
        return self.conn.cursor()

    def commit(self):
        self.conn.commit()

    def rollback(self):
        self.conn.rollback()

def GetDetail(token):
    '''
    获取数据
    '''
    SQLGetYhm="select * from data,auth where auth.yhm=data.yhm and auth.token='%s' order by id desc limit 1"%(token)
    db=DB()
    db.cur.execute(SQLGetYhm)
    data=db.cur.fetchall()
    if len(data)>0:
        return True,list(data[0][:-1])
    else:
        return False,None

def DoControl(token,target,status):
    '''
    控制
    '''
    db=DB()
    SQLGetYhm = "select * from data,auth where auth.yhm=data.yhm and auth.token='%s'  order by id desc limit 1" % (token)
    db.cur.execute(SQLGetYhm)
    data=db.cur.fetchall()
    if len(data)>0:
        data=data[0]
        yhm=data[3]
        times=str(datetime.datetime.now())
        # SQL = "update data set %s='%s' where yhm='%s'" % (target, status, yhm)
        SQL="insert into data" \
            "(device_id,time_stamp,yhm," \
            "lrlight,lrair_temp,lrair_flag,lrair_switch,door,window," \
            "brlight,brair_temp,brair_flag,brair_switch,kcswitch,kcsmoke,tem,hum)" \
            "values" \
            "('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')"\
            %(data[1],times,data[3],data[4],data[5],data[6],data[7],data[8],data[9],data[10],data[11],data[12],data[13],data[14],data[15],data[16],data[17])
        try:
            db.cur.execute(SQL)
            db.commit()
        except:
            db.rollback()
        try:
            SQLGetYhm = "select data.id from data where data.yhm='%s' order by id desc limit 1" % (yhm)
            db.cur.execute(SQLGetYhm)
            data=db.cur.fetchall()
            id=data[0][0]
            SQL = "update data set %s='%s' where id='%s'" % (target, status, id)
            db.cur.execute(SQL)
            db.commit()
        except:
            db.rollback()
    else:
        return False

def GetData(token,limit):
    '''
    获取多条数据
    '''
    db=DB()
    SQLGetYhm = "select data.yhm from data,auth where auth.yhm=data.yhm and auth.token='%s' order by id desc limit 1" % (token)
    db.cur.execute(SQLGetYhm)
    data=db.cur.fetchall()
    yhm=data[0][0]
    SQL="select * from data where yhm='%s' order by id desc limit %s"%(yhm,limit)
    db.cur.execute(SQL)
    data=db.cur.fetchall()
    size=len(data)
    res=[]
    for item in data:
        res.append(list(item))
    return {"size":size,"data":res}

def LocalControl(device_id):
    '''
    中控
    '''
    try:
        db = DB()
        SQLGetYhm = "select * from data where device_id='%s'  order by id desc limit 1" % (device_id)
        db.cur.execute(SQLGetYhm)
        data = db.cur.fetchall()
        if len(data) > 0:
            data = data[0]
            times = getTime()
            temp = data[16]
            hum = data[17]
            ntemp, nhum = getRandom(temp, hum)
            SQL = "insert into data" \
                  "(device_id,time_stamp,yhm," \
                  "lrlight,lrair_temp,lrair_flag,lrair_switch,door,window," \
                  "brlight,brair_temp,brair_flag,brair_switch,kcswitch,kcsmoke,tem,hum)" \
                  "values" \
                  "('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')" \
                  % (data[1], times, data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11],
                     data[12], data[13], data[14], data[15], data[16], data[17])
            try:
                db.cur.execute(SQL)
                db.commit()
            except:
                db.rollback()
            try:
                SQLGetYhm = "select data.id from data where device_id='%s' order by id desc limit 1" % (device_id)
                db.cur.execute(SQLGetYhm)
                data = db.cur.fetchall()
                id = data[0][0]
                SQL = "update data set tem='%s',hum='%s' where id='%s'" % (ntemp, nhum, id)
                db.cur.execute(SQL)
                db.commit()
            except:
                db.rollback()
        else:
            return False
    except:
        pass

def GetDataL(device_id):
    '''
    中控获取数据
    '''
    db=DB()
    SQL="select * from data where device_id='%s' order by id desc limit 1"%(device_id)
    db.cur.execute(SQL)
    data=db.cur.fetchone()
    data=list(data)
    return data


def getTime():
    date = str(datetime.datetime.now())
    time = date.split('.')[0]
    return time

def getRandom(temp, hum):
    temp = int(temp)
    hum = int(hum)
    p1 = random.randint(-3, 3)
    p2 = random.randint(-3, 3)
    temp = temp + p1
    hum = hum + p2
    if 16<temp<30 and 20<hum<100:
        return temp, hum
    else:
        return 20,50

def GetDataPic(token,limit):
    '''
    绘图数据
    '''
    db=DB()
    SQLGetYhm = "select data.yhm from data,auth where auth.yhm=data.yhm and auth.token='%s' order by id desc limit 1" % (token)
    db.cur.execute(SQLGetYhm)
    data=db.cur.fetchall()
    if len(data)>0:
        yhm = data[0][0]
        SQL = "select * from data where yhm='%s' order by id desc limit %s" % (yhm, limit)
        db.cur.execute(SQL)
        data = db.cur.fetchall()
        size = len(data)
        res = []
        for item in data:
            new = [item[2], item[16], item[17]]
            res.append(new)
        res.reverse()
        return {"size": size, "data": res}
    else:
        return {"size":"0","data":"null"}

# if __name__=='__main__':
#     print(GetDataPic('bteyqmjgao','2'))
