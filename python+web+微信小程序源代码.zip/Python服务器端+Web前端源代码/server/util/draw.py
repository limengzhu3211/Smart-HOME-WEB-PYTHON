from pyecharts import EffectScatter,Timeline
import sqlite3
import datetime
import random
BASE_PATH="/media/sh/软件/code/pycode/HomeAPI/server/DataBase/"
# BASE_PATH="/opt/flask/test/HomeAPI/server/DataBase/"
class DB():
    '''
    封装数据库类
    '''
    def __init__(self):
        self.conn=sqlite3.connect(BASE_PATH+'database')
        self.cur=self.conn.cursor()


    def getcur(self):
        return self.conn.cursor()

    def commit(self):
        self.conn.commit()

    def rollback(self):
        self.conn.rollback()

def draw1(token):
    timeline = Timeline(is_auto_play=True, timeline_bottom=0)
    data=getdata(token)
    for item in data.items():
        hour=str(item[0])+":00"
        v1=[i for i in range(1,len(item[1])+1)]
        v2=item[1]
        label=EffectScatter(hour+"|室内温度变化")
        label.add("", v1, v2)
        timeline.add(label, hour)
    return timeline

def draw2(token):
    timeline = Timeline(is_auto_play=True, timeline_bottom=0)
    data=getdata2(token)
    for item in data.items():
        hour=str(item[0])+":00"
        v1=[i for i in range(1,len(item[1])+1)]
        v2=item[1]
        label=EffectScatter(hour+"|室内湿度变化")
        label.add("", v1, v2)
        timeline.add(label, hour)
    return timeline


    # v1 = [1,2,3,4,5,6]
    # v2 = ["10", "20", "30", "40", "50", "60"]
    #
    # es1 = EffectScatter("室内温度变化")
    # es1.add("", v1, v2,is_label_show=True)
    #
    # v1 = [1,2,3,4,5,6]
    # v2 = ["122", "20", "30", "40", "50", "60"]
    #
    # es2 = EffectScatter("室内温度变化")
    # es2.add("", v1, v2,is_label_show=True)
    #
    # v1 = [1,2,3,4,5,6]
    # v2 = ["143", "20", "30", "40", "50", "60"]
    #
    # es3 = EffectScatter("室内温度变化")
    # es3.add("", v1, v2,is_label_show=True)
    # timeline = Timeline(is_auto_play=True, timeline_bottom=0)
    # timeline.add(es1,'14:30')
    # timeline.add(es2,'14:40')
    # timeline.add(es3,'14:50')
    # return timeline

def getdata(token):
    SQLGetYhm="select * from data,auth where auth.yhm=data.yhm and auth.token='%s' "%(token)
    db=DB()
    db.cur.execute(SQLGetYhm)
    data=db.cur.fetchall()
    dic={7:[],8:[],9:[],10:[],11:[],12:[],13:[],14:[],15:[],16:[],17:[],18:[],19:[]}
    for item in data:
        time=item[2][11:13]
        if len(dic[int(time)])<1000:
            dic[int(time)].append(item[16])
    return dic

def getdata2(token):
    SQLGetYhm="select * from data,auth where auth.yhm=data.yhm and auth.token='%s' "%(token)
    db=DB()
    db.cur.execute(SQLGetYhm)
    data=db.cur.fetchall()
    dic={7:[],8:[],9:[],10:[],11:[],12:[],13:[],14:[],15:[],16:[],17:[],18:[],19:[]}
    for item in data:
        time=item[2][11:13]
        if len(dic[int(time)])<1000:
            dic[int(time)].append(item[17])
    return dic


# if __name__=='__main__':
#     draw('pqgdruzfbh')