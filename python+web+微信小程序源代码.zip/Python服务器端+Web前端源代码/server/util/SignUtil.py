import sqlite3
import random
import time
import datetime
BASE_PATH="/media/sh/软件/code/pycode/HomeAPI/server/DataBase/"
# BASE_PATH="/opt/flask/test/HomeAPI/server/DataBase/"
class DB():
    '''
    封装数据库类
    '''
    def __init__(self):
        self.conn=sqlite3.connect(BASE_PATH+'database')
        self.cur=self.conn.cursor()


    def getcur(self):
        return self.conn.cursor()

    def commit(self):
        self.conn.commit()

    def rollback(self):
        self.conn.rollback()

def DoSignin(yhm,passwd,device):#TODO 在data表中插入默认数据
    '''
    处理注册表单  进行注册
    :param 注册参数
    :rtype 布尔值 判断操作是否成功
    '''
    SQLsign="insert into user (device_id,yhm,passwd)values('%s','%s','%s')"%(device,yhm,passwd)
    db=DB()
    token= "".join(random.sample(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
                             'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
                             'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
                             'y', 'z'], 10))
    SQLtoken = "insert into auth values('%s','%s')" % (yhm, token)
    res="注册成功"
    tf=True
    try:#注册用户
        db.cur.execute(SQLsign)
        db.commit()
    except:
        res='用户注册出错'
        tf=False
        db.rollback()
    try:#注册token
        db.cur.execute(SQLtoken)
        db.commit()
    except:
        db.rollback()
        res=res+" token注册出错"
        SQLtoken = "update auth set token='%s' where yhm='%s'" % (token, yhm)
        db.cur.execute(SQLtoken)
        tf = False
        db.commit()
    try:
        times=str(datetime.datetime.now())
        SQLdata="insert into data(device_id,time_stamp,yhm)values('%s','%s','%s')"%(device,times,yhm)
        db.cur.execute(SQLdata)
        db.commit()
    except:
        db.rollback()
        tf = False
        res=res+" data初始化出错"
    return tf,token



def IsSigned(yhm,passwd):
    '''
    判断用户名是否正确
    :param yhm passwd 参数
    :rtype 布尔值
    '''
    try:
        if "'" in yhm:
            yhm.replace("'", "")
        if "'" in passwd:
            passwd.replace("'", "")
        SQLquery = "select * from user where yhm='%s' and passwd='%s'" % (yhm, passwd)
        db = DB()
        db.cur.execute(SQLquery)
        data = db.cur.fetchall()
        token = "".join(random.sample(['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h',
                                       'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
                                       'q', 'r', 's', 't', 'u', 'v', 'w', 'x',
                                       'y', 'z'], 10))
        if len(data) > 0:
            try:
                SQLtoken = "insert into auth values('%s','%s')" % (yhm, token)
                db.cur.execute(SQLtoken)
                db.commit()
            except:
                db.rollback()
                SQLtoken = "update auth set token='%s' where yhm='%s'" % (token, yhm)
                db.cur.execute(SQLtoken)
                db.commit()
            return True, token
        else:
            return False, token
    except:
        return False,'null'

# if __name__=='__main__':
#     print(DoSignin('123456','156','789'))
#     print(IsSigned('123456','156'))