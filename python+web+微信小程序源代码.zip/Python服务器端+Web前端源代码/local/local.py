import time
import os
import requests
import datetime

DEVICE_ID="testid"

def do():
    requests.get("https://www.zhuizhu21.cn:8443/doLocalControl?device_id="+DEVICE_ID)

def show():
    html=requests.get("https://www.zhuizhu21.cn:8443/localData?device_id="+ DEVICE_ID)
    return html.json()

def getTime():
    date = str(datetime.datetime.now())
    time = date.split('.')[0]
    return time

if __name__=='__main__':
    while True:
        time.sleep(5)
        print("%s|家庭中控数上传"%(getTime()))
        do()
        print("%s|服务器控制数据%s" % (getTime(),show()))
